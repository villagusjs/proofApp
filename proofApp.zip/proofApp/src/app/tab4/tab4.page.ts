import { Component } from '@angular/core';
import { Facebook } from '@ionic-native/facebook/ngx';
import { ActivatedRoute, Router } from '@angular/router';
import {HomePage} from '../home/home.page';

@Component({
  selector: 'app-tab4',
  templateUrl: './tab4.page.html',
  styleUrls: ['./tab4.page.scss']
})

export class Tab4Page {

  isLoggedIn = true;

  constructor(public fb: Facebook) {

  }

  logout() {
    this.fb.logout()
    .then(res => this.isLoggedIn = false)
    .catch(e => console.log('Error logout from Facebook', e));
  }

}
